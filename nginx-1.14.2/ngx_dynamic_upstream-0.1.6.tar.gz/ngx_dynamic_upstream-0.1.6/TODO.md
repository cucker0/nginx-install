 * `backup` parameter
 * `upstream` under `stream` context
